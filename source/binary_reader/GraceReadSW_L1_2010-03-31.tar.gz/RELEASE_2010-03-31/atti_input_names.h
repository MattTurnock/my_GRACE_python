/*$Id: atti_input_names.h,v 1.1 2009/06/03 22:56:37 glk Exp $ */

#define ATTI_N_INPUT_NAMES 18

char *atti_input_names[] = {
                 "PQ_0", "PQ_1", "PQ_2", "OMEGA_0", "OMEGA_1", "OMEGA_2",
                 "ANGSCALE_X", "ANGSCALE_Y", "ANGSCALE_Z", "ANGBIAS_X", "ANGBIAS_Y", "ANGBIAS_Z",
                 "CAM1BIAS_X", "CAM1BIAS_Y", "CAM1BIAS_Z", "CAM2BIAS_X", "CAM2BIAS_Y", "CAM2BIAS_Z"
};
